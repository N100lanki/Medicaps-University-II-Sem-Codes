
import java.util.Scanner;
import java.util.jar.Attributes.Name;
public class Student {
    int rollNo;
    String name;
void getdata( ){
    
    this.rollNo=rollNo;
    this.name=name;
     System.out.println("Enter Student Name :");
     System.out.println("Enter Roll Number  :");
     


}
    public static void 3main(String [] args){

        Scanner sc = new Scanner(System.in);
        int rollNo=sc.nextInt();



    }
    
}
