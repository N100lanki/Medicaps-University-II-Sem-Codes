public class stati 
{

    static void display()
    { 
    System.out.println("lakhan joshi \nThe Lodu Lakhan");
    }

public static void main(String [] args) 
{
  stati.display();    
}
}
