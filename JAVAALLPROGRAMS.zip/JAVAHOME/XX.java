import Add.*;

import ADD.Addition;
public class XX {
    public static void main(String[] args) {
         Addition obj = new Addition();
         obj.sub(50, 10); 
    }
    
}
