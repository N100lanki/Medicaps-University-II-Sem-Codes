package Ninjan;

public class Niru {
    
}
