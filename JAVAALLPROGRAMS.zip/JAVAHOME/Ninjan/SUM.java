package Ninjan;

public class SUM {
    int sum(int x,int y){
        return(x+y);
    }
    
}
