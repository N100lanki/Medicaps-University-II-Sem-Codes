import java.Addition.*;
public class ADD {
    public static void main(String[] args) {
        sum obj = new sum();
        obj.add(10,20);
        
    }
    
}
