package ADD;
public class PACK {

 int sum(int x,int y){
     return(x+y);
 }  
 public static void main(String[] args) {
     
     PACK obj = new PACK();
     obj.sum(10,200);
 } 
}
