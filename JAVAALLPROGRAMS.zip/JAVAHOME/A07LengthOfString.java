import java.util.Scanner;
public class A07LengthOfString {
    public static void main(String[] a)
{
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Strings:");
        String s1 =sc.nextLine();
        System.out.print("Length of String:"+s1.length());
        
}
}
