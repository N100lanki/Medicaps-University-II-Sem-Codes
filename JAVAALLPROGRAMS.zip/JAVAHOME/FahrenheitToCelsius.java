 import java.util.Scanner;

 public class FahrenheitToCelsius {
 public static void main(String[] args) {
 Scanner input = new Scanner(System.in);

 System.out.print("Enter a degree in Fahrenheit: ");celsius = ()( fahrenheit - 32).
Case Study: Displaying the Current Time 
line# fahrenheit celsius
double fahrenheit = input.nextDouble(); 

 // Convert Fahrenheit to Celsius
 double celsius = * (fahrenheit - 32);
 System.out.println("Fahrenheit " + fahrenheit + " is " +
 celsius + " in Celsius");
 }
 }