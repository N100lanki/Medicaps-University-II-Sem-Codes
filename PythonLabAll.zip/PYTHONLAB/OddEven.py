# 6.Odd_Even
num = int(input("Enter a number to check it is odd or even: "))
print(num, "is Even.") if (num % 2 == 0) else print(num, "is Odd.")