def isPalindrome(list):
    if str1 == str1[::-1]:
        return True
    else:
        return False


str1 =input("Enter the String :")
print("Is palindrome:",isPalindrome(str1))