from re import L


#input list
List=eval(input("Enter list (Enclose it in Squar Bracket ):"))
print(List)
#Change String to char list
s=input("Enter STring to convert in to List:")
l=list(s)
print("Your list is :",l)
#for i in List:
s1=input("Enter STring to convert in to List:")
l=s1.split()
print("your String Splited in word list:",l)
