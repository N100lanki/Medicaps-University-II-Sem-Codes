r =  float (input ("Please enter the radius of the given circle: ")) 
pi=3.14
area=pi*r*r
print (area)
