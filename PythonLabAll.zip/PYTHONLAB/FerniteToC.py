f = float(input('Enter Temprature in Feranite: '))
c=(f-32)*5/9
print(c)
