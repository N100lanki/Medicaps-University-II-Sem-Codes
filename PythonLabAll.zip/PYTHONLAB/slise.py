str1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" 
print(str1[1])
print(str1[-1:1:-1]) 
