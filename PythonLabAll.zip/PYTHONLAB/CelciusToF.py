c = float(input('Enter Temprature in Celsius: '))
f=c*(9/5)+32
print(c)
