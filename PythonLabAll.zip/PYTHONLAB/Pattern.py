# Nested for loop

for i in range(1,6): #Outer for loop(no. of rows)
	for j in range(1,6): #Inner for loop(no. of cols)
		print(i,end="") #Data to be displayed
	print() 


'''
Base pattern:-

11111
22222
33333
44444
55555

'''
 