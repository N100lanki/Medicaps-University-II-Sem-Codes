list = [ "Niranjan","solanki" ]
for i in list:
	if(i == "solanki") :
		print (i,"Element Exists")

print("")
        
