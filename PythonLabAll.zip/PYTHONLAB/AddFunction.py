def add(a,b):
    print("a+b=",a+b)
a=float(input("Enter Value of a"))
b=float(input("Enter Value of b"))
add(a,b)
def division(a,b):
    print("a+b=",a/b)
a=float(input("Enter Value of a"))
b=float(input("Enter Value of b"))
division(a,b)
def modulus(a,b):
    print("a%b=",a%b)
a=float(input("Enter Value of a"))
b=float(input("Enter Value of b"))
modulus(a,b)
def subtraction(a,b):
    print("a+b=",a-b)
a=float(input("Enter Value of a"))
b=float(input("Enter Value of b"))
modulus(a,b)
def multiplication(a,b,c):
    print("a*b*c=",(a*b*c))
a=float(input("Enter Value of a"))
b=float(input("Enter Value of b"))
c=float(input("Enter Value of c"))
multiplication(a,b,c)
 
'''   print("Hello ",name ,msg)
name=input("Enter Name:")
msg=input("Enter Mesage:")
greet(name,msg)'''