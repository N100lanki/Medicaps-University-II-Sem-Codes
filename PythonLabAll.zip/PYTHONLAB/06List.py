'''6. Create a list containing the names of students and count the occurrence of name Neha in the
list.'''
namelist = [
    "Adams",
    "Baker",
    "Neha",
    "Clark",
    "Davis",
    "Evans",
    "Frank",
    "Ghosh",
    "Neha",
    "Hills",
    "Irwin",
    "Jones",
    "Klein",
    "Lopez",
    "Mason",
    "Neha",
    "Nalty",
    "Ochoa",
    "Patel",
    "Quinn",
    "Reily",
]
print("Number of Occurence of Neha in list :", namelist.count("Neha"))