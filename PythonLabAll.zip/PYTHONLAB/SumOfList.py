list1 =eval(input("Enter Int\Float Elements in the  List(Enclose with []) "))
sum=0
for i in range(0, len(list1)):
	sum+=list1[i]
print("Sum of all elements of the  list: ", sum)
