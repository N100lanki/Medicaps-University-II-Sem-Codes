'''12. Create two sets s1={1,2,3,4} and s2={2,4,5,6} perform following operations on sets. (a)
Union (b) intersection (c) difference (d) symmetric difference'''
A = {1,2,3,4};
B = {2, 4, 5,6};
# union
print("Union :", A | B)
# intersection
print("Intersection :", A & B)
# difference
print("Difference :", A - B)
# symmetric difference
print("Symmetric difference :", A ^ B)
