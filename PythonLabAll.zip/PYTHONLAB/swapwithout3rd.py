a =int(input("Enter A :"))
b =int(input("Enter A :"))
print("Values of A is ",a)
print("Values of B is ",b)
a,b=b,a
print("Values of A is ",a)
print("Values of B is ",b)
