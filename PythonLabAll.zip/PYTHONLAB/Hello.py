j=0
for j in range(j,1,10):
 print("Hello Ninjan !")