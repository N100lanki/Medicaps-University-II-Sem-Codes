a =input('Enter First Number: ')
b =input('Enter Second Number: ')
print(" Values of A is ",a)
print(" Values of B is ",b)
c=a
a=b
b=c
print("Values of A is ",a)
print("Values of B is ",b)
