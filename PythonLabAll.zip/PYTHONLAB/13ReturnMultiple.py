'''14. Write a program for returning multiple values from a function.'''
def fun():
	str = "Niranjan Solanki"
	id = 12345
	return str,id; 
str, id = fun() 
print(str)
print(id)
