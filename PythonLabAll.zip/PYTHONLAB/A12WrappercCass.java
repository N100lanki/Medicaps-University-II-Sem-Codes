//Convert one data type to another using wrapper classes
class A12WrapperClass{
  public static void main(String args[]){
    String s = "10";
    int a = Integer.parseInt(s);
    System.out.print("Before the value is string : ");
    System.out.println(s+10);
    System.out.print("After the value is converted into Integer : ");
    System.out.println(a+10);
  }
} 
