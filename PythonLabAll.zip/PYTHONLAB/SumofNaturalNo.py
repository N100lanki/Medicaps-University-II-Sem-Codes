# 18 sum of n natural numbers
num = int(input("Enter number limit : "))
sum = 0
for i in range(1, num + 1):
    sum += i
print(sum)