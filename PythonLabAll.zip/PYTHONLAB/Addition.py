Python 3.10.2 (tags/v3.10.2:a58ebcc, Jan 17 2022, 14:12:15) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
print('Hello Ninjan')
Hello Ninjan
print("Hello Ninjan")
Hello Ninjan
print(' "Medicaps University" ')
 "Medicaps University" 
print(""Medicaps University"")
SyntaxError: invalid syntax. Perhaps you forgot a comma?
print(' "Medicaps University" ')
 "Medicaps University" 
print(" "Medicaps University" ")
SyntaxError: invalid syntax. Perhaps you forgot a comma?
a=10,b=20,c
SyntaxError: invalid syntax. Maybe you meant '==' or ':=' instead of '='?
a=10
b=12
c=a+b
print("Addition is ",c)
Addition is  22
