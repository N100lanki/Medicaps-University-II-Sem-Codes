c = input("Enter A Character:") 
print("The ASCII value of '" + c + "' is", ord(c))
