class Proffe :
    attr1="Developer"
    attr2="Software Engineer"
    def fun (self):
        print("i am  a ",self.attr1)
        print("i am ",self.attr2)
obj=Proffe()
obj.fun()
print(obj.attr1)
