r = float(input('Rate: '))
t = int(input('Enter Time: '))
p = float(input('Principle Amount: '))
si= (r*t*p)/100
print(si)
