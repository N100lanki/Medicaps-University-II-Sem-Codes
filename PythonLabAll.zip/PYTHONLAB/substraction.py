a = 19
b = 21

Subtraction = b - a

print(Subtraction)
