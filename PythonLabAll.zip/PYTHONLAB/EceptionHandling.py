a=input("enter number")
b=input("enter number")
print("A=",a)
print("B=",b)
try:
    c=int.a+int.b
    print("Addition :",c)
    print("Addition SuccessFull!!")
except Exception as E:
    print("Cant perform addition because of Error ",E)
print("Thank you !!!! End of application")
