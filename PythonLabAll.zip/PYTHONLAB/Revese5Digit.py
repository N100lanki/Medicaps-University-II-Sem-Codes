#  Reverse of 5 digit number
num = input("Enter any 5 digit number : ")
print(num[::-1])