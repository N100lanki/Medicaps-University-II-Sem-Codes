name = "Niranjan"
prof="Developer"
print(f"Hello ! i am {name} and i am a {prof}")