def add():
    global a         #global Variable declaration
    a=10
    print(a)
def Sub():
    print(a)
add()
Sub()
# Local variable declaration
'''def add1():         
    b=10
    print(b)
def Sub1():
    print(b)
add1()
Sub1()
'''