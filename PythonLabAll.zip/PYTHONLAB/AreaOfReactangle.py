a = float(input('Enter first side: '))
b = float(input('Enter second side: '))
area=a*b
print(area)
